package com.example.flutter_riverpod_one_habibi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
